"""
Generador de ficheros SEPA Direct Debit (pain.008.001.02)
Sustituto del antiguo Cuaderno 19 (N19)

Especificación: ISO 20022
"""

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom import minidom
import uuid
import re


@dataclass
class DatosMandato:
    """Datos del mandato SEPA (autorización de domiciliación)"""
    mandate_id: str                    # Referencia única del mandato
    fecha_firma: date                  # Fecha de firma
    deudor_nombre: str                 # Nombre del deudor
    deudor_iban: str                   # IBAN del deudor
    deudor_bic: Optional[str] = None   # BIC (opcional)
    tipo: str = 'RCUR'                 # RCUR=Recurrente, OOFF=Único, FRST=Primera, FNAL=Final
    
    def __post_init__(self):
        # Limpiar IBAN
        self.deudor_iban = self.deudor_iban.replace(' ', '').upper()


@dataclass
class ReciboSEPA:
    """Recibo individual para incluir en remesa SEPA"""
    id_interno: str                    # Referencia interna
    importe: Decimal                   # Importe a cobrar
    concepto: str                      # Concepto (máx 140 caracteres)
    mandato: DatosMandato              # Datos del mandato
    end_to_end_id: Optional[str] = None  # ID trazabilidad
    
    def __post_init__(self):
        if not self.end_to_end_id:
            self.end_to_end_id = f"E2E-{self.id_interno}-{uuid.uuid4().hex[:8].upper()}"
        # Truncar concepto a 140 caracteres
        self.concepto = self.concepto[:140]


@dataclass
class ConfiguracionAcreedorSEPA:
    """Configuración del acreedor SEPA (quien cobra)"""
    creditor_id: str      # Identificador acreedor SEPA (ES + control + sufijo + NIF)
    creditor_name: str    # Nombre del acreedor
    creditor_iban: str    # IBAN del acreedor
    creditor_bic: Optional[str] = None  # BIC
    esquema: str = 'CORE' # CORE (particulares), B2B (empresas), COR1 (rápido)
    
    def __post_init__(self):
        self.creditor_iban = self.creditor_iban.replace(' ', '').upper()


def validar_iban(iban: str) -> bool:
    """Valida un IBAN español"""
    iban = iban.replace(' ', '').upper()
    
    if not re.match(r'^ES\d{22}$', iban):
        return False
    
    # Mover los 4 primeros caracteres al final
    iban_reordenado = iban[4:] + iban[:4]
    
    # Convertir letras a números (A=10, B=11, etc.)
    iban_numerico = ''
    for char in iban_reordenado:
        if char.isalpha():
            iban_numerico += str(ord(char) - ord('A') + 10)
        else:
            iban_numerico += char
    
    # Módulo 97
    return int(iban_numerico) % 97 == 1


def validar_creditor_id(creditor_id: str) -> bool:
    """Valida un identificador de acreedor SEPA español"""
    # Formato: ES + 2 dígitos control + 3 caracteres sufijo + NIF
    # Ejemplo: ES12000B12345678
    if not re.match(r'^ES\d{2}[A-Z0-9]{3}[A-Z0-9]{9}$', creditor_id):
        return False
    return True


class GeneradorSEPADirectDebit:
    """
    Genera ficheros SEPA Direct Debit (pain.008.001.02)
    para domiciliaciones bancarias.
    
    Uso:
        config = ConfiguracionAcreedorSEPA(
            creditor_id="ES12000B12345678",
            creditor_name="MI EMPRESA SL",
            creditor_iban="ES9121000418450200051332"
        )
        
        generador = GeneradorSEPADirectDebit(config)
        generador.agregar_recibo(recibo1)
        generador.agregar_recibo(recibo2)
        
        xml = generador.generar_xml(fecha_cobro=date(2024, 2, 5))
    """
    
    NAMESPACE = "urn:iso:std:iso:20022:tech:xsd:pain.008.001.02"
    
    def __init__(self, config: ConfiguracionAcreedorSEPA):
        self.config = config
        self.recibos: List[ReciboSEPA] = []
        self.mensaje_id: str = ""
        self.fecha_cobro: date = date.today()
        
        # Validar configuración
        if not validar_iban(config.creditor_iban):
            raise ValueError(f"IBAN del acreedor no válido: {config.creditor_iban}")
    
    def agregar_recibo(self, recibo: ReciboSEPA) -> None:
        """Añade un recibo a la remesa"""
        # Validar IBAN del deudor
        if not validar_iban(recibo.mandato.deudor_iban):
            raise ValueError(f"IBAN del deudor no válido: {recibo.mandato.deudor_iban}")
        
        self.recibos.append(recibo)
    
    def generar_mensaje_id(self) -> str:
        """Genera un Message ID único"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        random_part = uuid.uuid4().hex[:8].upper()
        self.mensaje_id = f"SEPA-{timestamp}-{random_part}"
        return self.mensaje_id
    
    def calcular_total(self) -> Decimal:
        """Calcula el importe total de la remesa"""
        return sum(r.importe for r in self.recibos)
    
    def generar_xml(self, fecha_cobro: date) -> str:
        """
        Genera el fichero XML SEPA Direct Debit completo.
        
        Args:
            fecha_cobro: Fecha de cargo solicitada (mínimo D+2 para CORE, D+1 para COR1)
        
        Returns:
            String con el XML completo
        """
        self.fecha_cobro = fecha_cobro
        
        if not self.mensaje_id:
            self.generar_mensaje_id()
        
        if not self.recibos:
            raise ValueError("No hay recibos en la remesa")
        
        # Validar fecha de cobro
        dias_minimos = 1 if self.config.esquema == 'COR1' else 2
        if (fecha_cobro - date.today()).days < dias_minimos:
            raise ValueError(f"Fecha de cobro debe ser al menos D+{dias_minimos}")
        
        # Crear documento XML
        doc = Element('Document', xmlns=self.NAMESPACE)
        cstmr_drct_dbt = SubElement(doc, 'CstmrDrctDbtInitn')
        
        # Group Header
        self._agregar_group_header(cstmr_drct_dbt)
        
        # Payment Information (agrupado por tipo de secuencia)
        self._agregar_payment_info(cstmr_drct_dbt)
        
        # Formatear XML
        xml_str = tostring(doc, encoding='unicode')
        xml_pretty = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        # Limpiar y añadir declaración XML correcta
        lines = xml_pretty.split('\n')
        xml_final = '\n'.join(line for line in lines[1:] if line.strip())
        xml_final = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_final
        
        return xml_final
    
    def _agregar_group_header(self, parent: Element) -> None:
        """Añade la cabecera del grupo (GrpHdr)"""
        grp_hdr = SubElement(parent, 'GrpHdr')
        
        # Message Identification (máx 35 caracteres)
        SubElement(grp_hdr, 'MsgId').text = self.mensaje_id[:35]
        
        # Creation Date Time (ISO format)
        SubElement(grp_hdr, 'CreDtTm').text = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        
        # Number of Transactions
        SubElement(grp_hdr, 'NbOfTxs').text = str(len(self.recibos))
        
        # Control Sum (2 decimales)
        SubElement(grp_hdr, 'CtrlSum').text = f"{self.calcular_total():.2f}"
        
        # Initiating Party (quien genera el fichero)
        initg_pty = SubElement(grp_hdr, 'InitgPty')
        SubElement(initg_pty, 'Nm').text = self.config.creditor_name[:70]
        
        # Identification del iniciador
        id_elem = SubElement(initg_pty, 'Id')
        org_id = SubElement(id_elem, 'OrgId')
        othr = SubElement(org_id, 'Othr')
        SubElement(othr, 'Id').text = self.config.creditor_id
    
    def _agregar_payment_info(self, parent: Element) -> None:
        """Añade la información de pago (PmtInf)"""
        
        # Agrupar recibos por tipo de secuencia (FRST, RCUR, OOFF, FNAL)
        por_secuencia = {}
        for recibo in self.recibos:
            seq = recibo.mandato.tipo
            if seq not in por_secuencia:
                por_secuencia[seq] = []
            por_secuencia[seq].append(recibo)
        
        # Crear un PmtInf por cada tipo de secuencia
        for idx, (seq_type, recibos_grupo) in enumerate(por_secuencia.items()):
            pmt_inf = SubElement(parent, 'PmtInf')
            
            # Payment Information Identification
            pmt_inf_id = f"{self.mensaje_id[:26]}-{seq_type}-{idx:02d}"
            SubElement(pmt_inf, 'PmtInfId').text = pmt_inf_id[:35]
            
            # Payment Method (siempre DD para Direct Debit)
            SubElement(pmt_inf, 'PmtMtd').text = 'DD'
            
            # Batch Booking (true = un apunte bancario por remesa)
            SubElement(pmt_inf, 'BtchBookg').text = 'true'
            
            # Number of Transactions in this payment info
            SubElement(pmt_inf, 'NbOfTxs').text = str(len(recibos_grupo))
            
            # Control Sum for this payment info
            ctrl_sum = sum(r.importe for r in recibos_grupo)
            SubElement(pmt_inf, 'CtrlSum').text = f"{ctrl_sum:.2f}"
            
            # Payment Type Information
            pmt_tp_inf = SubElement(pmt_inf, 'PmtTpInf')
            svc_lvl = SubElement(pmt_tp_inf, 'SvcLvl')
            SubElement(svc_lvl, 'Cd').text = 'SEPA'
            lcl_instrm = SubElement(pmt_tp_inf, 'LclInstrm')
            SubElement(lcl_instrm, 'Cd').text = self.config.esquema
            SubElement(pmt_tp_inf, 'SeqTp').text = seq_type
            
            # Requested Collection Date
            SubElement(pmt_inf, 'ReqdColltnDt').text = self.fecha_cobro.isoformat()
            
            # Creditor (acreedor)
            cdtr = SubElement(pmt_inf, 'Cdtr')
            SubElement(cdtr, 'Nm').text = self.config.creditor_name[:70]
            
            # Creditor Account
            cdtr_acct = SubElement(pmt_inf, 'CdtrAcct')
            cdtr_acct_id = SubElement(cdtr_acct, 'Id')
            SubElement(cdtr_acct_id, 'IBAN').text = self.config.creditor_iban
            
            # Creditor Agent (banco del acreedor)
            cdtr_agt = SubElement(pmt_inf, 'CdtrAgt')
            fin_instn_id = SubElement(cdtr_agt, 'FinInstnId')
            if self.config.creditor_bic:
                SubElement(fin_instn_id, 'BIC').text = self.config.creditor_bic
            else:
                othr = SubElement(fin_instn_id, 'Othr')
                SubElement(othr, 'Id').text = 'NOTPROVIDED'
            
            # Creditor Scheme Identification
            cdtr_schme_id = SubElement(pmt_inf, 'CdtrSchmeId')
            id_elem = SubElement(cdtr_schme_id, 'Id')
            prvt_id = SubElement(id_elem, 'PrvtId')
            othr = SubElement(prvt_id, 'Othr')
            SubElement(othr, 'Id').text = self.config.creditor_id
            schme_nm = SubElement(othr, 'SchmeNm')
            SubElement(schme_nm, 'Prtry').text = 'SEPA'
            
            # Direct Debit Transaction Information (cada recibo)
            for recibo in recibos_grupo:
                self._agregar_transaccion(pmt_inf, recibo)
    
    def _agregar_transaccion(self, parent: Element, recibo: ReciboSEPA) -> None:
        """Añade una transacción (recibo) individual (DrctDbtTxInf)"""
        drct_dbt_tx_inf = SubElement(parent, 'DrctDbtTxInf')
        
        # Payment Identification
        pmt_id = SubElement(drct_dbt_tx_inf, 'PmtId')
        SubElement(pmt_id, 'EndToEndId').text = recibo.end_to_end_id[:35]
        
        # Instructed Amount
        instd_amt = SubElement(drct_dbt_tx_inf, 'InstdAmt', Ccy='EUR')
        instd_amt.text = f"{recibo.importe:.2f}"
        
        # Direct Debit Transaction (información del mandato)
        drct_dbt_tx = SubElement(drct_dbt_tx_inf, 'DrctDbtTx')
        mndt_rltd_inf = SubElement(drct_dbt_tx, 'MndtRltdInf')
        SubElement(mndt_rltd_inf, 'MndtId').text = recibo.mandato.mandate_id[:35]
        SubElement(mndt_rltd_inf, 'DtOfSgntr').text = recibo.mandato.fecha_firma.isoformat()
        
        # Debtor Agent (banco del deudor)
        dbtr_agt = SubElement(drct_dbt_tx_inf, 'DbtrAgt')
        fin_instn_id = SubElement(dbtr_agt, 'FinInstnId')
        if recibo.mandato.deudor_bic:
            SubElement(fin_instn_id, 'BIC').text = recibo.mandato.deudor_bic
        else:
            othr = SubElement(fin_instn_id, 'Othr')
            SubElement(othr, 'Id').text = 'NOTPROVIDED'
        
        # Debtor (deudor)
        dbtr = SubElement(drct_dbt_tx_inf, 'Dbtr')
        SubElement(dbtr, 'Nm').text = recibo.mandato.deudor_nombre[:70]
        
        # Debtor Account
        dbtr_acct = SubElement(drct_dbt_tx_inf, 'DbtrAcct')
        dbtr_acct_id = SubElement(dbtr_acct, 'Id')
        SubElement(dbtr_acct_id, 'IBAN').text = recibo.mandato.deudor_iban
        
        # Remittance Information (concepto)
        rmt_inf = SubElement(drct_dbt_tx_inf, 'RmtInf')
        SubElement(rmt_inf, 'Ustrd').text = recibo.concepto[:140]
    
    def guardar_fichero(self, ruta: str) -> None:
        """Guarda el XML en un fichero"""
        xml = self.generar_xml(self.fecha_cobro)
        with open(ruta, 'w', encoding='utf-8') as f:
            f.write(xml)
    
    def obtener_resumen(self) -> dict:
        """Devuelve un resumen de la remesa"""
        return {
            'mensaje_id': self.mensaje_id,
            'fecha_cobro': self.fecha_cobro.isoformat(),
            'num_recibos': len(self.recibos),
            'importe_total': float(self.calcular_total()),
            'esquema': self.config.esquema,
            'acreedor': {
                'nombre': self.config.creditor_name,
                'iban': self.config.creditor_iban,
                'creditor_id': self.config.creditor_id
            }
        }


# =====================================================
# EJEMPLO DE USO
# =====================================================

if __name__ == "__main__":
    # Configuración del acreedor (comunidad de propietarios)
    config = ConfiguracionAcreedorSEPA(
        creditor_id="ES12000H03123456",
        creditor_name="COMUNIDAD PROP. EDIFICIO LOS NARANJOS",
        creditor_iban="ES91 2100 0418 4502 0005 1332",
        creditor_bic="CAIXESBBXXX",
        esquema="CORE"
    )
    
    # Crear generador
    generador = GeneradorSEPADirectDebit(config)
    
    # Añadir recibos de cuotas
    propietarios = [
        ("GARCÍA MARTÍNEZ, JUAN", "ES79 2100 0813 6101 2345 6789", 125.50, "1A"),
        ("LÓPEZ FERNÁNDEZ, MARÍA", "ES47 2038 5778 9830 0076 0236", 125.50, "1B"),
        ("MARTÍNEZ RUIZ, PEDRO", "ES60 0049 1500 0512 3456 7892", 95.00, "Local"),
    ]
    
    for nombre, iban, importe, piso in propietarios:
        mandato = DatosMandato(
            mandate_id=f"MAND-{piso}",
            fecha_firma=date(2024, 1, 15),
            deudor_nombre=nombre,
            deudor_iban=iban,
            tipo='RCUR'
        )
        
        recibo = ReciboSEPA(
            id_interno=f"REC-2024-02-{piso}",
            importe=Decimal(str(importe)),
            concepto=f"Cuota ordinaria Febrero 2024 - {piso}",
            mandato=mandato
        )
        
        generador.agregar_recibo(recibo)
    
    # Generar XML para cobrar el día 5 del mes siguiente
    from datetime import timedelta
    fecha_cobro = date.today() + timedelta(days=5)
    
    xml = generador.generar_xml(fecha_cobro)
    
    print("=" * 60)
    print("REMESA SEPA DIRECT DEBIT GENERADA")
    print("=" * 60)
    print(f"Mensaje ID: {generador.mensaje_id}")
    print(f"Recibos: {len(generador.recibos)}")
    print(f"Importe total: {generador.calcular_total():.2f} €")
    print(f"Fecha cobro: {fecha_cobro}")
    print("=" * 60)
    print("\nXML generado:\n")
    print(xml[:2000] + "\n...[truncado]...")
