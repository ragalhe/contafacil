#!/bin/bash
# =====================================================
# ContaFácil - Script de Inicio Rápido
# =====================================================

echo "🚀 ContaFácil - Configuración Inicial"
echo "======================================"

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 no encontrado. Por favor, instálalo primero."
    exit 1
fi

echo "✅ Python encontrado: $(python3 --version)"

# Crear entorno virtual
echo ""
echo "📦 Creando entorno virtual..."
python3 -m venv venv

# Activar entorno
source venv/bin/activate 2>/dev/null || source venv/Scripts/activate 2>/dev/null

# Instalar dependencias
echo ""
echo "📥 Instalando dependencias..."
pip install --upgrade pip
pip install -r requirements.txt

# Crear carpetas necesarias
mkdir -p uploads temp

# Copiar archivo de secretos de ejemplo
if [ ! -f .streamlit/secrets.toml ]; then
    echo ""
    echo "⚙️ Creando archivo de configuración..."
    cp .streamlit/secrets.toml.example .streamlit/secrets.toml
    echo "⚠️  IMPORTANTE: Edita .streamlit/secrets.toml con tus claves API"
fi

echo ""
echo "======================================"
echo "✅ Instalación completada!"
echo ""
echo "Para iniciar la aplicación, ejecuta:"
echo ""
echo "  source venv/bin/activate"
echo "  streamlit run app_main.py"
echo ""
echo "La aplicación se abrirá en: http://localhost:8501"
echo "======================================"
